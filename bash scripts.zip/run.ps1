$script = Read-Host("what script do ya wanna run?")

Invoke-Expression("./$script");